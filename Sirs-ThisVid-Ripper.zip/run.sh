#!/bin/bash
cd "$(dirname "$0")"
pip3 install -r requirements.txt --quiet 2>/dev/null
python3 thisvid_scraper.py
