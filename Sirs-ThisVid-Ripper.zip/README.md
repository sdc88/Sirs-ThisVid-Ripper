# 🎬 Sir's ThisVid Ripper

Bulk download videos from ThisVid. Install once, run from anywhere.

---

## ⚡ Install

```bash
pip install sirsthisvid
```

That's it.

---

## 🚀 Run

Open Terminal (Mac/Linux) or Command Prompt (Windows) and type:

```bash
sirsthisvid
```

You'll see:

```
═══════════════════════════════════════════════════════════
  🎬 SIR'S THISVID RIPPER  v2.0.0
═══════════════════════════════════════════════════════════

  What do you want to download?

  [1] 🏷️  Tag — videos with a specific tag
  [2] 👤 Profile — all videos from a user
  [3] 📺 All Videos — newest gay or straight
  [4] ⏩ Resume — continue where you left off
  [5] 🔄 Check for updates
  [0] 🚪 Exit

  Choice:
```

Just pick a number and follow the prompts!

---

## 📝 Examples

**Download all "feet" videos (gay, popular):**
1. Run `sirsthisvid`
2. Pick `[1] Tag`
3. Type: `feet`
4. Pick `[1] Gay`
5. Pick `[1] Popular`
6. Press Enter to save to Desktop
7. Wait!

**Download someone's profile:**
1. Run `sirsthisvid`
2. Pick `[2] Profile`
3. Go to their profile, copy the number from the URL (e.g. `960704` from `thisvid.com/members/960704`)
4. Paste it
5. Wait!

**If it stops or crashes:**
Run `sirsthisvid` again and pick `[4] Resume`

---

## 🔄 Update

```bash
pip install --upgrade sirsthisvid
```

Or pick `[5] Check for updates` in the menu.

---

## ❓ Troubleshooting

**"sirsthisvid: command not found"**
→ Make sure Python is in your PATH. Try: `python -m sirsthisvid`

**"pip: command not found"**
→ Install Python from [python.org](https://python.org/downloads) — tick "Add to PATH"

**Some videos fail**
→ They might be private or deleted. The tool skips them.

---

## 🗑️ Uninstall

```bash
pip uninstall sirsthisvid
```

---

## 📜 License

[CC0](LICENSE) — Do whatever you want.

---

**More from Sir:** [The Vault+](https://thevault.locker) · [The Cult of Sir](https://cultofsir.com) · [Sir Store](https://sirdominic.store)
